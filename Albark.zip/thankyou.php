<?php include "include/menu.php"?>
<?php include "include/header.php"?>


<div id="particles-js"></div>
    <div class="thank-you-container">
<div class="thank-you-box">
  <h1>Thank you!</h1>
  <p class="lead">for contacting us</p>
  <p>We are excited to hear back from you!</p>
  <p class="signature">Team SURA ALBARK</p>
  <p>Accounting and Booking</p>
</div>
<a class="return-black" href="index">Return to Website</a>
</div>

<?php include "include/footer.php"?>

